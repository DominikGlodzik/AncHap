comparePairHaps <- function(haps1, haps2) {


}
